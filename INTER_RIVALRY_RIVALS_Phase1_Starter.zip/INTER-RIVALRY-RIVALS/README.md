# INTER RIVALRY: RIVALS — Phase 1 Starter

New, separate browser FPS practice prototype. It does not replace or edit the existing INTER RIVALRY website or PWA files.

## Deploy to GitHub Pages
1. Extract this ZIP.
2. Upload the **rivals** folder to the root of your existing `Inter-Rivalry-BCU` repository. Final paths must be `rivals/index.html`, `rivals/style.css`, and `rivals/game.js`.
3. Do not replace root `index.html`, manifest, service worker, or other existing files.
4. Commit, then open `https://inter-rivalry.github.io/Inter-Rivalry-BCU/rivals/`.

## Controls
Desktop: WASD / arrow keys move, mouse aim, click shoot, Space jump, R reload, Escape pause. Android: left joystick move, drag right side to aim, FIRE shoots, JUMP jumps.

## Limitations
This is a single-player practice prototype, not online multiplayer. Matchmaking, private rooms, server-authoritative combat, and persistent scores are not implemented yet. Three.js loads from jsDelivr, so internet access is required. Test before sharing widely.
